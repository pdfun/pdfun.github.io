###演示地址###
[演示地址](http://mufeng.me/hermit-for-wordpress.html "Hermit 演示地址 ")


###Hermit Beta 更新历史###
1.1.0 (14-4-30)  
1. 新增函数 <code>window.hermitInit()</code>修复Ajax加载页面，具体的例子参考：[Hermit Ajax加载](http://imufeng.github.io/hermit-ajax.html "Hermit Ajax加载")  
2. 删除其他代码, wordpress版本可以在官方插件库下载 [Wordpress Hermit插件](https://wordpress.org/plugins/hermit/ "Wordpress Hermit插件")


1.0.42 (14-4-14)  
1. Bug修复  
2. 入口函数修改  

1.0.41 (14-4-12)  
1. Bug 修复  

1.0.4 (14-4-11)  
1. 增加自动播放, 参数为`auto=1`  
2. 增加循环播放, 参数为`loop=1`

1.0.24 (14-2-20)  
1. 增加一个定时器

1.0.23 (14-2-18)  
1. 添加精选集

1.0.22 (14-2-16)  
1. 删除全局变量window.player

1.0.2  (14-2-15)  
1.  更换一个正在播放的图标

1.0.1  (14-2-13)  
1.  专辑添加最大高度360px;  
2.  歌曲信息为null报错的问题;  
3.  专辑、单曲地址错误提示，单曲列表去重复;  
4.  服务器地址迁移回Bae

1.0.0  (14-2-11)  
1.  最初1.0.0版本发布


###感谢开源项目###
[SoundManager 2](https://github.com/scottschiller/SoundManager2 "SoundManager 2")


如果你对这个插件感兴趣, 敬请关注:  
[作者的博客](http://mufeng.me/ "作者的博客")  
[插件发布页](http://mufeng.me/hermit-for-wordpress.html "插件发布页")
